Here's the description of the board files:

anykey.drl      : Drill rack file
anykey.drd      : Excellon Drill description (using device EXCELLON)
anykey.dri      : Excellon Drill tool description (using device EXCELLON)
anykey.cmp      : Top/component layer
anykey.stc      : Solder resist (top/component side)
anykey.plc      : Silkscreen (top/component side)
anykey.sol      : Bottom/solder layer
anykey.sts      : Solder resist (bottom/solder side)
anykey.pls      : Silkscreen (bottom/solder side)
anykey.gpi      : Gerber photoplotter information data
anykey-rack.drd : Excellon Drill description (using device EXCELLON-RACK)
anykey-rack.dri : Excellon Drill tool description (using device EXCELLON-RACK)

I followed your online PDF guide to build Gerber files from EAGLE. The drill data dialog in my Version (6.10) is different from your guide - the default EXCELLON device did not use the drl file. However, they looked fine in various viewers, so I used them. Just to be safe, I also exported drd and dri files using the EXCELLON-RACK setting. Please check which version meets your requirements.

The other files were generated using your guide. In addition, I added a .pls file for the bottom side silkscreen print. Since I specified white solder resist, please use black silkscreen.

If you encounter problems with the files, please contact me.